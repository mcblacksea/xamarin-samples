﻿using Xamarin.Forms;

[assembly: XmlnsDefinition("http://sharpnado.com", "Sharpnado.Shades")]
[assembly: XmlnsPrefix("http://sharpnado.com", "sho")]