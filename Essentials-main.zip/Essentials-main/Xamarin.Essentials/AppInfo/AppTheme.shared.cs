﻿namespace Xamarin.Essentials
{
    public enum AppTheme
    {
        Unspecified,
        Light,
        Dark
    }
}
