﻿namespace Xamarin.Essentials
{
#if !NETSTANDARD
    public static partial class Platform
    {
    }
#endif
}
