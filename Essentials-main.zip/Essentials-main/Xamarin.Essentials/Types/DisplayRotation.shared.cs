﻿namespace Xamarin.Essentials
{
    public enum DisplayRotation
    {
        Unknown = 0,
        Rotation0 = 1,
        Rotation90 = 2,
        Rotation180 = 3,
        Rotation270 = 4
    }
}
