﻿namespace Xamarin.Essentials
{
    public enum DisplayOrientation
    {
        Unknown = 0,
        Portrait = 1,
        Landscape = 2
    }
}
