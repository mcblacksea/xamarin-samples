﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("XamarinEssentialsTests")]
[assembly: InternalsVisibleTo("XamarinEssentialsDeviceTestsAndroid")]
[assembly: InternalsVisibleTo("XamarinEssentialsDeviceTestsUWP")]
[assembly: InternalsVisibleTo("XamarinEssentialsDeviceTestsShared")]
[assembly: InternalsVisibleTo("XamarinEssentialsDeviceTestsiOS")]
