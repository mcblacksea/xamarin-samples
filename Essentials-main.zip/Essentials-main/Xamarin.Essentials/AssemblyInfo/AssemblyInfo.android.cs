﻿using Android;

[assembly: LinkerSafe]
