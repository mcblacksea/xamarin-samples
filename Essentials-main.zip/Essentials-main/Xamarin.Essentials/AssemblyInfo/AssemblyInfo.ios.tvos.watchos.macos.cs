﻿using Foundation;

#pragma warning disable CS0618 // Type or member is obsolete
[assembly: LinkerSafe]
#pragma warning restore CS0618 // Type or member is obsolete
