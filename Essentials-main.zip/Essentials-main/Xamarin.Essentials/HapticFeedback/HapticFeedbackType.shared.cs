﻿namespace Xamarin.Essentials
{
    public enum HapticFeedbackType
    {
        Click,
        LongPress
    }
}
