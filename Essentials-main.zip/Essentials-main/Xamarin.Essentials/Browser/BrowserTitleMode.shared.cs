﻿namespace Xamarin.Essentials
{
    public enum BrowserTitleMode
    {
        Default = 0,
        Show = 1,
        Hide = 2
    }
}
