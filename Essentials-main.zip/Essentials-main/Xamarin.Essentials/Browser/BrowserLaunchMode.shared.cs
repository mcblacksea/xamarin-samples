﻿namespace Xamarin.Essentials
{
    public enum BrowserLaunchMode
    {
        SystemPreferred = 0,
        External = 1
    }
}
