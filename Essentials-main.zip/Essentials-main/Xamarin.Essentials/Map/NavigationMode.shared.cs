﻿namespace Xamarin.Essentials
{
    public enum NavigationMode
    {
        None = 0,
        Default = 1,
        Bicycling = 2,
        Driving = 3,
        Transit = 4,
        Walking = 5,
    }
}
