﻿namespace Samples.View
{
    public partial class ContactDetailsPage
    {
        public ContactDetailsPage()
        {
            InitializeComponent();
        }
    }
}
