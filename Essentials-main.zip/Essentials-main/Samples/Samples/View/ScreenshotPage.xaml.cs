﻿namespace Samples.View
{
    public partial class ScreenshotPage : BasePage
    {
        public ScreenshotPage()
        {
            InitializeComponent();
        }
    }
}
