﻿namespace Samples.View
{
    public partial class UnitConvertersPage : BasePage
    {
        public UnitConvertersPage()
        {
            InitializeComponent();
        }
    }
}
