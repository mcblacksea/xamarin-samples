﻿namespace Samples.View
{
    public partial class PreferencesPage : BasePage
    {
        public PreferencesPage()
        {
            InitializeComponent();
        }
    }
}
