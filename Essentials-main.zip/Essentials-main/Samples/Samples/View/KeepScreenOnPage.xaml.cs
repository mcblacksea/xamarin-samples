﻿namespace Samples.View
{
    public partial class KeepScreenOnPage : BasePage
    {
        public KeepScreenOnPage()
        {
            InitializeComponent();
        }
    }
}
