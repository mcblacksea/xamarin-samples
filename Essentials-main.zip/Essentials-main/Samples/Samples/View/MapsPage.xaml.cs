﻿using Xamarin.Forms.Xaml;

namespace Samples.View
{
    public partial class MapsPage : BasePage
    {
        public MapsPage()
        {
            InitializeComponent();
        }
    }
}
