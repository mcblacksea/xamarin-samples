﻿namespace Samples.View
{
    public partial class FlashlightPage : BasePage
    {
        public FlashlightPage()
        {
            InitializeComponent();
        }
    }
}
