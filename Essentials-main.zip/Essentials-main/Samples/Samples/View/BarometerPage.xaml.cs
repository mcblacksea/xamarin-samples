﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Samples.View
{
    public partial class BarometerPage : BasePage
    {
        public BarometerPage()
        {
            InitializeComponent();
        }
    }
}
