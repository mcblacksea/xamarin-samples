﻿using Xamarin.Forms.Xaml;

namespace Samples.View
{
    public partial class MediaPickerPage : BasePage
    {
        public MediaPickerPage()
        {
            InitializeComponent();
        }
    }
}
