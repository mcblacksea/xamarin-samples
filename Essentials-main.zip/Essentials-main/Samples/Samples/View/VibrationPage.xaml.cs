﻿namespace Samples.View
{
    public partial class VibrationPage : BasePage
    {
        public VibrationPage()
        {
            InitializeComponent();
        }
    }
}
