﻿namespace Samples.View
{
    public partial class AccelerometerPage : BasePage
    {
        public AccelerometerPage()
        {
            InitializeComponent();
        }
    }
}
