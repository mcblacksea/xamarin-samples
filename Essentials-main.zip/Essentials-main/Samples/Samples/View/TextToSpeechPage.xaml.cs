﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace Samples.View
{
    public partial class TextToSpeechPage : BasePage
    {
        public TextToSpeechPage()
        {
            InitializeComponent();
        }
    }
}
