﻿namespace Samples.View
{
    public partial class GeolocationPage : BasePage
    {
        public GeolocationPage()
        {
            InitializeComponent();
        }
    }
}
