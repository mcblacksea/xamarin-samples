﻿namespace Samples.View
{
    public partial class ConnectivityPage : BasePage
    {
        public ConnectivityPage()
        {
            InitializeComponent();
        }
    }
}
