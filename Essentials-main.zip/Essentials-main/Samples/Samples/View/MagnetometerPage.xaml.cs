﻿namespace Samples.View
{
    public partial class MagnetometerPage : BasePage
    {
        public MagnetometerPage()
        {
            InitializeComponent();
        }
    }
}
