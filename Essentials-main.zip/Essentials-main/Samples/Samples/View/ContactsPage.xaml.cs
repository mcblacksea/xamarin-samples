﻿namespace Samples.View
{
    public partial class ContactsPage
    {
        public ContactsPage()
        {
            InitializeComponent();
        }
    }
}
