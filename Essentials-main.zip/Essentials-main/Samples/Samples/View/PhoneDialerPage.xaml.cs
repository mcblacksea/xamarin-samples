﻿namespace Samples.View
{
    public partial class PhoneDialerPage : BasePage
    {
        public PhoneDialerPage()
        {
            InitializeComponent();
        }
    }
}
