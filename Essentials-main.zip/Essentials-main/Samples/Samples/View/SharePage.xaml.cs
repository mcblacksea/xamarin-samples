﻿namespace Samples.View
{
    public partial class SharePage : BasePage
    {
        public SharePage()
        {
            InitializeComponent();
        }
    }
}
