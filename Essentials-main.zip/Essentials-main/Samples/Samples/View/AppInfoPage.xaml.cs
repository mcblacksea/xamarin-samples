﻿namespace Samples.View
{
    public partial class AppInfoPage : BasePage
    {
        public AppInfoPage()
        {
            InitializeComponent();
        }
    }
}
