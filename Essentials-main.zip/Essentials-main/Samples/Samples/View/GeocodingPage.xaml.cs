﻿namespace Samples.View
{
    public partial class GeocodingPage : BasePage
    {
        public GeocodingPage()
        {
            InitializeComponent();
        }
    }
}
