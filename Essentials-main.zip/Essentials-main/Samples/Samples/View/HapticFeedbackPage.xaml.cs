﻿namespace Samples.View
{
    public partial class HapticFeedbackPage : BasePage
    {
        public HapticFeedbackPage()
        {
            InitializeComponent();
        }
    }
}
