﻿namespace Samples.View
{
    public partial class ClipboardPage : BasePage
    {
        public ClipboardPage()
        {
            InitializeComponent();
        }
    }
}
