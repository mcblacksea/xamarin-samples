﻿namespace Samples.View
{
    public partial class BatteryPage : BasePage
    {
        public BatteryPage()
        {
            InitializeComponent();
        }
    }
}
