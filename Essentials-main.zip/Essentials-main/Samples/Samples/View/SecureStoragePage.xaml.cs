﻿namespace Samples.View
{
    public partial class SecureStoragePage : BasePage
    {
        public SecureStoragePage()
        {
            InitializeComponent();
        }
    }
}
