﻿namespace Samples.View
{
    public partial class DeviceInfoPage : BasePage
    {
        public DeviceInfoPage()
        {
            InitializeComponent();
        }
    }
}
