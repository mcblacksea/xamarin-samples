﻿namespace Samples.View
{
    public partial class EmailPage : BasePage
    {
        public EmailPage()
        {
            InitializeComponent();
        }
    }
}
