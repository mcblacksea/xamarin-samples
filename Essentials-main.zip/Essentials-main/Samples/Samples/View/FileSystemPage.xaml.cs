﻿namespace Samples.View
{
    public partial class FileSystemPage : BasePage
    {
        public FileSystemPage()
        {
            InitializeComponent();
        }
    }
}
