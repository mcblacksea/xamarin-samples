﻿namespace Samples.View
{
    public partial class FilePickerPage : BasePage
    {
        public FilePickerPage()
        {
            InitializeComponent();
        }
    }
}
