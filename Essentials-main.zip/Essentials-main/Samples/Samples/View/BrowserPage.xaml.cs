﻿namespace Samples.View
{
    public partial class BrowserPage : BasePage
    {
        public BrowserPage()
        {
            InitializeComponent();
        }
    }
}
