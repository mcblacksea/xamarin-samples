﻿namespace Samples.View
{
    public partial class CompassPage : BasePage
    {
        public CompassPage()
        {
            InitializeComponent();
        }
    }
}
