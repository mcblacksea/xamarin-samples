﻿namespace Samples.View
{
    public partial class ColorConvertersPage : BasePage
    {
        public ColorConvertersPage()
        {
            InitializeComponent();
        }
    }
}
