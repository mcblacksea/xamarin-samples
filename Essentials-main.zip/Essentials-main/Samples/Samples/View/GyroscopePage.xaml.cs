﻿namespace Samples.View
{
    public partial class GyroscopePage : BasePage
    {
        public GyroscopePage()
        {
            InitializeComponent();
        }
    }
}
