﻿namespace Samples.View
{
    public partial class SMSPage : BasePage
    {
        public SMSPage()
        {
            InitializeComponent();
        }
    }
}
