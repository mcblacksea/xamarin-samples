﻿namespace Samples.View
{
    public partial class OrientationSensorPage : BasePage
    {
        public OrientationSensorPage()
        {
            InitializeComponent();
        }
    }
}
