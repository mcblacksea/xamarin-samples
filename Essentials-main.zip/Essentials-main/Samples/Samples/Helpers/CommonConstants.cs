﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Samples.Helpers
{
    public static class CommonConstants
    {
        internal const string AppCenterAndroid = "AC_ANDROID";
        internal const string AppCenteriOS = "AC_IOS";
        internal const string AppCenterUWP = "AC_UWP";
    }
}
