﻿using Xamarin.Essentials;
using Xunit;

namespace Tests
{
    public class Email_Tests
    {
    }
}
