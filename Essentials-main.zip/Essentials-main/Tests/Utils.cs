﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Essentials;

namespace Tests
{
    public static class TestUtils
    {
        public static void EnableExperimentalFeatures()
        {
        }
    }
}
