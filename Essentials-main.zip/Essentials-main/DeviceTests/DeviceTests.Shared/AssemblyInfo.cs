﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("XamarinEssentialsDeviceTestsAndroid")]
[assembly: InternalsVisibleTo("XamarinEssentialsDeviceTestsUWP")]
[assembly: InternalsVisibleTo("XamarinEssentialsDeviceTestsiOS")]
