﻿using Xamarin.Essentials;
using Xunit;

namespace DeviceTests
{
    public class PhoneDialer_Tests
    {
    }
}
