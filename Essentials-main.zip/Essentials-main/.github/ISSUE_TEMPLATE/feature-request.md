---
name: Feature request
about: Suggest an idea for Essentials
title: "[Enhancement] YOUR IDEA!"
labels: feature-request 
assignees: ''

---
We are no longer accepting new feature request for Xamarin.Essentials. Please make your new feature requests in the .NET MAUI repo which contains .NET MAUI Essentials at https://github.com/dotnet/maui.
