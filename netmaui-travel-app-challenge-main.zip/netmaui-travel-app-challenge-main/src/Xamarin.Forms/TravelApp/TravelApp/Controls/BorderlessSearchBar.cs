﻿using Xamarin.Forms;

namespace TravelApp.Controls
{
    public class BorderlessSearchBar : SearchBar
    {

    }
}
