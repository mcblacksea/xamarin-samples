using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]

[assembly: ExportFont("rockolf.ttf", Alias = "Rockolf")]
[assembly: ExportFont("rockoflf-bold.ttf", Alias = "Rockolf Bold")]
[assembly: ExportFont("rockoultraflf.ttf", Alias = "Rockoultraflf")]
[assembly: ExportFont("rockoultraflf-bold.ttf", Alias = "Rockoultraflf Bold")]


[assembly: ExportFont("MaterialIcons-Regular.ttf", Alias = "Material")] 