﻿using Xamarin.Forms;

namespace TravelApp.Views.Templates
{
    public partial class TopItemTemplate : ContentView
    {
        public TopItemTemplate()
        {
            InitializeComponent();
        }
    }
}