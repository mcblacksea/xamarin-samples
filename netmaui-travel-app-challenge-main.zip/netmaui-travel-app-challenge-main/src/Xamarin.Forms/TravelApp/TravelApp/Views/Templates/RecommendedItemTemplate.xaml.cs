﻿using Xamarin.Forms;

namespace TravelApp.Views.Templates
{
    public partial class RecommendedItemTemplate : ContentView
    {
        public RecommendedItemTemplate()
        {
            InitializeComponent();
        }
    }
}