﻿using Xamarin.Forms;

namespace TravelApp.Views.Templates
{
    public partial class GalleryItemTemplate : ContentView
    {
        public GalleryItemTemplate()
        {
            InitializeComponent();
        }
    }
}