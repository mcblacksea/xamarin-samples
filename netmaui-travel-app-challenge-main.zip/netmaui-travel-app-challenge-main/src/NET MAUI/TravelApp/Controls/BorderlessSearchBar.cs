﻿namespace TravelApp.Controls
{
    public class BorderlessSearchBar : SearchBar
    {

    }
}
