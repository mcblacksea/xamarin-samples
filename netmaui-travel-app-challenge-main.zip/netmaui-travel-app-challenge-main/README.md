# Travel App - .NET MAUI UI Challenge

_(Work in progress)_

Travel App UI Challenge made with .NET MAUI (and Xamarin.Forms).

![TravelApp](images/travelapp-maui.png)

Based on this [design](https://dribbble.com/shots/15793197-Travel-App) by [Arya Wijaya](https://dribbble.com/aweka) and using ilutrations by [pikisuperstar](https://www.freepik.com/pikisuperstar).