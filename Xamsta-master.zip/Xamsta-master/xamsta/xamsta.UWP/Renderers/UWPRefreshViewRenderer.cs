﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Xamarin.Forms;
using Xamarin.Forms.Platform.UWP;
using xamsta.UWP.Renderers;

//[assembly: ExportRenderer(typeof(RefreshView), typeof(UWPRefreshViewRenderer))]
namespace xamsta.UWP.Renderers
{
    //public class UWPRefreshViewRenderer : ViewRenderer<RefreshView, RefreshContainer>
    //{
    //    protected override void OnElementChanged(ElementChangedEventArgs<RefreshView> e)
    //    {
    //        base.OnElementChanged(e);
    //        if (Control != null)
    //        {
    //            Control.Visibility = Windows.UI.Xaml.Visibility.Visible;
    //            Control.IsEnabled = true;
    //            Control.KeyTipVerticalOffset = 150;
    //        }
    //    }
    //}
}
