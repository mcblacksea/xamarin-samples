﻿namespace xamsta.Views
{
    public partial class SettingsView
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
}