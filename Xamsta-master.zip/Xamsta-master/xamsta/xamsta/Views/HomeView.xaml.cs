﻿namespace xamsta.Views
{
    public partial class HomeView 
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}