﻿namespace xamsta.Helpers
{
    public interface IStatusBar
    {
        int GetHeight();
    }
}
