﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class GridSplitter : ResourceDictionary
    {
        public GridSplitter()
        {
            InitializeComponent();
        }
    }
}