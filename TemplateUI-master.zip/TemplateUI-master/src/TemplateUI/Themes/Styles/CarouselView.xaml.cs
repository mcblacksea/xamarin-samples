﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class CarouselView : ResourceDictionary
    {
        public CarouselView()
        {
            InitializeComponent();
        }
    }
}