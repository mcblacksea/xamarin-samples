﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Shield : ResourceDictionary
    {
        public Shield()
        {
            InitializeComponent();
        }
    }
}