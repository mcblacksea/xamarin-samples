﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class ComparerView : ResourceDictionary
    {
        public ComparerView()
        {
            InitializeComponent();
        }
    }
}
