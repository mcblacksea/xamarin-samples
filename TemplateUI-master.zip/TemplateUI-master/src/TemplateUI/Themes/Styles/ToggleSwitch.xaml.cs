﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class ToggleSwitch : ResourceDictionary
    {
        public ToggleSwitch()
        {
            InitializeComponent();
        }
    }
}
