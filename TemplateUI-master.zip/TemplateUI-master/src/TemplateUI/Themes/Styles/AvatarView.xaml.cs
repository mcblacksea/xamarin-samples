﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class AvatarView : ResourceDictionary
    {
        public AvatarView()
        {
            InitializeComponent();
        }
    }
}