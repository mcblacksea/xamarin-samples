﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class BarChart : ResourceDictionary
    {
        public BarChart()
        {
            InitializeComponent();
        }
    }
}
