﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class LineChart : ResourceDictionary
    {
        public LineChart()
        {
            InitializeComponent();
        }
    }
}