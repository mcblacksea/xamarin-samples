﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class BadgeView : ResourceDictionary
    {
        public BadgeView()
        {
            InitializeComponent();
        }
    }
}