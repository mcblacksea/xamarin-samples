﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Rate : ResourceDictionary
    {
        public Rate()
        {
            InitializeComponent();
        }
    }
}