﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class PinBox : ResourceDictionary
    {
        public PinBox()
        {
            InitializeComponent();
        }
    }
}