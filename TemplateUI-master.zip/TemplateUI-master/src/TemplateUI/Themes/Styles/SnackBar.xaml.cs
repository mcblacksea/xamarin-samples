﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class SnackBar : ResourceDictionary
    {
        public SnackBar()
        {
            InitializeComponent();
        }
    }
}