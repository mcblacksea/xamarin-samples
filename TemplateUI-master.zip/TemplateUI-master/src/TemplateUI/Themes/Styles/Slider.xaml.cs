﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Slider : ResourceDictionary
    {
        public Slider()
        {
            InitializeComponent();
        }
    }
}