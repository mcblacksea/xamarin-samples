﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class CircleProgressBar : ResourceDictionary
    {
        public CircleProgressBar()
        {
            InitializeComponent();
        }
    }
}
