﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class AreaChart : ResourceDictionary
    {
        public AreaChart()
        {
            InitializeComponent();
        }
    }
}
