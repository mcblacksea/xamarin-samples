﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Marquee : ResourceDictionary
    {
        public Marquee()
        {
            InitializeComponent();
        }
    }
}
