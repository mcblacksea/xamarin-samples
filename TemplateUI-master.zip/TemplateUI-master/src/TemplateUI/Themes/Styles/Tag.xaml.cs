﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Tag : ResourceDictionary
    {
        public Tag()
        {
            InitializeComponent();
        }
    }
}