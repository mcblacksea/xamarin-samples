﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class GridLines : ResourceDictionary
    {
        public GridLines()
        {
            InitializeComponent();
        }
    }
}
