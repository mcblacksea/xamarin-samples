﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Divider : ResourceDictionary
    {
        public Divider()
        {
            InitializeComponent();
        }
    }
}