﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Generic : ResourceDictionary
    {
        public Generic()
        {
            InitializeComponent();
        }
    }
}
