﻿using Xamarin.Forms;

namespace TemplateUI.Themes
{
    public partial class Colors : ResourceDictionary
    {
        public Colors()
        {
            InitializeComponent();
        }
    }
}