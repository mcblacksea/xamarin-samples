﻿namespace TemplateUI.Controls
{
    public enum BadgePosition
    {
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    }
}