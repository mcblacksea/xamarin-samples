﻿namespace TemplateUI.Controls
{
    public enum SelectionMode
    {
        None,
        Single
    }
}