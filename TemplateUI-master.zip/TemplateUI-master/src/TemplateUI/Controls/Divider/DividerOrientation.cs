﻿namespace TemplateUI.Controls
{
    public enum DividerOrientation
    {
        Horizontal,
        Vertical
    }
}