﻿namespace TemplateUI.Controls
{
    public enum ChatBubbleType
    {
        Sender,
        Receiver
    }
}