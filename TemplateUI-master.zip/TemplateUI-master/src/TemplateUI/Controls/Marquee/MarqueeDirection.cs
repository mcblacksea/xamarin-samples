﻿namespace TemplateUI.Controls
{
    public enum MarqueeDirection
    {
        LeftToRight,
        RightToLeft
    }
}