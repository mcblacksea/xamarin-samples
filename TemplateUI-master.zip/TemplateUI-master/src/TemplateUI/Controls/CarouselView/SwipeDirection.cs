﻿namespace TemplateUI.Controls
{
    public enum SwipeDirection
    {
        RightToLeft = -1,
        LeftToRight = 1
    }
}