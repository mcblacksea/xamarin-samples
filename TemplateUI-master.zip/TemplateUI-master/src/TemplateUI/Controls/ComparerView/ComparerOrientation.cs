﻿namespace TemplateUI.Controls
{
    public enum ComparerOrientation
    {
        Horizontal,
        Vertical
    }
}