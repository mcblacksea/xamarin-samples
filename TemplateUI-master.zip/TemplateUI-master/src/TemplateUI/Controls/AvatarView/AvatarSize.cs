﻿namespace TemplateUI.Controls
{
    public enum AvatarSize
    {
        ExtraSmall,
        Small,
        Medium,
        Large,
        ExtraLarge
    }
}