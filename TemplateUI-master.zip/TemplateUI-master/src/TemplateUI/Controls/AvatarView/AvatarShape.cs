﻿namespace TemplateUI.Controls
{
    public enum AvatarShape
    {
        Circle,
        Square
    }
}