﻿namespace TemplateUI.Controls
{
    public enum VisualType
    {
        Cupertino,
        Fluent,
        Material
    }
}