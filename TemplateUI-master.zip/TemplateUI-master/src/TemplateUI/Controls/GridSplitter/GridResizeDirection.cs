﻿namespace TemplateUI.Controls
{
    public enum GridResizeDirection
    {
        Auto,
        Columns,
        Rows
    }
}