﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class ChatBubbleGallery : TabbedPage
    {
        public ChatBubbleGallery()
        {
            InitializeComponent();
        }
    }
}