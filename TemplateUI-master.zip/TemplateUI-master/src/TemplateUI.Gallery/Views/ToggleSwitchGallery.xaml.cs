﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class ToggleSwitchGallery : TabbedPage
    {
        public ToggleSwitchGallery()
        {
            InitializeComponent();
        }
    }
}