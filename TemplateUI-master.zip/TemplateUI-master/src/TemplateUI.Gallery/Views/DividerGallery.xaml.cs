﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class DividerGallery : ContentPage
    {
        public DividerGallery()
        {
            InitializeComponent();
        }
    }
}