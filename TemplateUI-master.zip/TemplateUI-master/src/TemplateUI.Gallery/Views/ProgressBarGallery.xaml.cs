﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class ProgressBarGallery : TabbedPage
    {
        public ProgressBarGallery()
        {
            InitializeComponent();
        }
    }
}