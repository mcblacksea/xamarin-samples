﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class AvatarViewGallery : TabbedPage
    {
        public AvatarViewGallery()
        {
            InitializeComponent();
        }
    }
}