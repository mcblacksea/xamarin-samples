﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class DockLayoutGallery : ContentPage
    {
        public DockLayoutGallery()
        {
            InitializeComponent();
        }
    }
}