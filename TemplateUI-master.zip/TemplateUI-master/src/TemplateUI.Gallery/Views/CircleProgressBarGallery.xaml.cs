﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class CircleProgressBarGallery : TabbedPage
    {
        public CircleProgressBarGallery()
        {
            InitializeComponent();
        }
    }
}