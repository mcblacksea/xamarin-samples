﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class BadgeViewGallery : TabbedPage
    {
        public BadgeViewGallery()
        {
            InitializeComponent();
        }
    }
}