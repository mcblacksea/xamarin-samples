﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class ComparerViewGallery : ContentPage
    {
        public ComparerViewGallery()
        {
            InitializeComponent();
        }
    }
}