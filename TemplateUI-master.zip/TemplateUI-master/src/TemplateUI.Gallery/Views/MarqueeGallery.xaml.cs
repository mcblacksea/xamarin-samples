﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class MarqueeGallery : TabbedPage
    {
        public MarqueeGallery()
        {
            InitializeComponent();
        }
    }
}