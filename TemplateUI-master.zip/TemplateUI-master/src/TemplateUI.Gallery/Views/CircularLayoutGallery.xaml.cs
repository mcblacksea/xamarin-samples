﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views
{
    public partial class CircularLayoutGallery : ContentPage
    {
        public CircularLayoutGallery()
        {
            InitializeComponent();
        }
    }
}