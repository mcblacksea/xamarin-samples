﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views.Templates
{
    public partial class GalleryItemTemplate : ContentView
    {
        public GalleryItemTemplate()
        {
            InitializeComponent();
        }
    }
}