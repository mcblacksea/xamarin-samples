﻿using Xamarin.Forms;

namespace TemplateUI.Gallery.Views.Templates
{
    public partial class TrendingItemTemplate : ContentView
    {
        public TrendingItemTemplate()
        {
            InitializeComponent();
        }
    }
}