﻿namespace TemplateUI.Gallery.Models
{
    public class ChartDataItem
    {
        public string Title { get; set; }
        public double Value { get; set; }
    }
}