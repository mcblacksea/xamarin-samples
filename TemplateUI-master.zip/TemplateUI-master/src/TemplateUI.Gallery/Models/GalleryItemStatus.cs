﻿namespace TemplateUI.Gallery.Models
{
    public enum GalleryItemStatus
    {
        Ready,
        Preview,
        InProgress,
        New
    }
}