# API diff: SkiaSharp.Views.UWP.dll

## SkiaSharp.Views.UWP.dll

### Namespace SkiaSharp.Views.UWP

#### Type Changed: SkiaSharp.Views.UWP.SKXamlCanvas

Modified base type:

```diff
-Windows.UI.Xaml.FrameworkElement
+Windows.UI.Xaml.Controls.Canvas
```



