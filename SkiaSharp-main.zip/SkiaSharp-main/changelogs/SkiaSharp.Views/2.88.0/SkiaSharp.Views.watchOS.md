# API diff: SkiaSharp.Views.watchOS.dll

## SkiaSharp.Views.watchOS.dll

> Assembly Version Changed: 2.88.0.0 vs 2.80.0.0

