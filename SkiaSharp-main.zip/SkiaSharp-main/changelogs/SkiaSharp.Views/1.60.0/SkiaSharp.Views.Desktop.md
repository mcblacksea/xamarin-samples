# API diff: SkiaSharp.Views.Desktop.dll

## SkiaSharp.Views.Desktop.dll

> Assembly Version Changed: 1.60.0.0 vs 1.59.0.0

### Namespace SkiaSharp.Views.Desktop

#### Type Changed: SkiaSharp.Views.Desktop.SKGLControl

Added constructors:

```csharp
public SKGLControl (OpenTK.Graphics.GraphicsMode mode);
public SKGLControl (OpenTK.Graphics.GraphicsMode mode, int major, int minor, OpenTK.Graphics.GraphicsContextFlags flags);
```



