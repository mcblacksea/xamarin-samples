# API diff: SkiaSharp.Views.Mac.dll

## SkiaSharp.Views.Mac.dll

> Assembly Version Changed: 1.56.0.0 vs 1.55.0.0

### Namespace SkiaSharp.Views.Mac

#### Type Changed: SkiaSharp.Views.Mac.Extensions

Removed methods:

```csharp
public static System.Drawing.Color ToDrawingColor (this SkiaSharp.SKColor color);
public static SkiaSharp.SKColor ToSKColor (this System.Drawing.Color color);
```



