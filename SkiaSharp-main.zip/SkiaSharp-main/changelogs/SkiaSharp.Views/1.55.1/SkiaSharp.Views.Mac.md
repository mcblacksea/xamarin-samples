# API diff: SkiaSharp.Views.Mac.dll

## SkiaSharp.Views.Mac.dll

### Namespace SkiaSharp.Views.Mac

#### Type Changed: SkiaSharp.Views.Mac.SKCanvasLayer

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```


#### Type Changed: SkiaSharp.Views.Mac.SKCanvasView

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```



