# API diff: SkiaSharp.Views.WPF.dll

## SkiaSharp.Views.WPF.dll

### Namespace SkiaSharp.Views.WPF

#### Type Changed: SkiaSharp.Views.WPF.SKElement

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```



