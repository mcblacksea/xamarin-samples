# API diff: SkiaSharp.Views.tvOS.dll

## SkiaSharp.Views.tvOS.dll

### Namespace SkiaSharp.Views.tvOS

#### Type Changed: SkiaSharp.Views.tvOS.SKCanvasLayer

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```


#### Type Changed: SkiaSharp.Views.tvOS.SKCanvasView

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```



