# API diff: SkiaSharp.Views.iOS.dll

## SkiaSharp.Views.iOS.dll

> No changes.
