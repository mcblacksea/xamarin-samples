# API diff: SkiaSharp.Views.Android.dll

## SkiaSharp.Views.Android.dll

> No changes.
