# API diff: SkiaSharp.Views.tvOS.dll

## SkiaSharp.Views.tvOS.dll

### Namespace SkiaSharp.Views.tvOS

#### Type Changed: SkiaSharp.Views.tvOS.SKGLLayer

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```


#### Type Changed: SkiaSharp.Views.tvOS.SKGLView

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```



