# API diff: SkiaSharp.Views.iOS.dll

## SkiaSharp.Views.iOS.dll

### Namespace SkiaSharp.Views.iOS

#### Type Changed: SkiaSharp.Views.iOS.SKGLLayer

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```


#### Type Changed: SkiaSharp.Views.iOS.SKGLView

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```



