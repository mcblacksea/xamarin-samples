# API diff: SkiaSharp.Views.Android.dll

## SkiaSharp.Views.Android.dll

### Namespace SkiaSharp.Views.Android

#### Type Changed: SkiaSharp.Views.Android.SKGLSurfaceView

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```


#### Type Changed: SkiaSharp.Views.Android.SKGLSurfaceViewRenderer

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```



