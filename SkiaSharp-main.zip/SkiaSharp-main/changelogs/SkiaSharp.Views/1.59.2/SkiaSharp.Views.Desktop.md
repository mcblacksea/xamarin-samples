# API diff: SkiaSharp.Views.Desktop.dll

## SkiaSharp.Views.Desktop.dll

### Namespace SkiaSharp.Views.Desktop

#### Type Changed: SkiaSharp.Views.Desktop.SKGLControl

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```



