# API diff: SkiaSharp.Views.Mac.dll

## SkiaSharp.Views.Mac.dll

### Namespace SkiaSharp.Views.Mac

#### Type Changed: SkiaSharp.Views.Mac.SKGLLayer

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```


#### Type Changed: SkiaSharp.Views.Mac.SKGLView

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```



