# API diff: SkiaSharp.Views.Desktop.dll

## SkiaSharp.Views.Desktop.dll

> Assembly Version Changed: 2.80.0.0 vs 1.68.0.0

