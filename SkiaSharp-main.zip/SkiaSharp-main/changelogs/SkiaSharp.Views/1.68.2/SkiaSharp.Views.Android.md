# API diff: SkiaSharp.Views.Android.dll

## SkiaSharp.Views.Android.dll

### Namespace SkiaSharp.Views.Android

#### Type Changed: SkiaSharp.Views.Android.SKPaintGLSurfaceEventArgs

Added constructor:

```csharp
public SKPaintGLSurfaceEventArgs (SkiaSharp.SKSurface surface, SkiaSharp.GRBackendRenderTarget renderTarget, SkiaSharp.GRSurfaceOrigin origin, SkiaSharp.SKColorType colorType, SkiaSharp.GRGlFramebufferInfo glInfo);
```


#### New Type: SkiaSharp.Views.Android.Resource

```csharp
public class Resource {
	// constructors
	public Resource ();

	// inner types
	public class Attribute {
	}
}
```


