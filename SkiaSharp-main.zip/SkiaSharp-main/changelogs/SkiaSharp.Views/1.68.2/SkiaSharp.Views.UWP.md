# API diff: SkiaSharp.Views.UWP.dll

## SkiaSharp.Views.UWP.dll

### Namespace SkiaSharp.Views.UWP

#### Type Changed: SkiaSharp.Views.UWP.AngleSwapChainPanel

Added method:

```csharp
protected virtual void OnDestroyingContext ();
```


#### Type Changed: SkiaSharp.Views.UWP.SKPaintGLSurfaceEventArgs

Added constructor:

```csharp
public SKPaintGLSurfaceEventArgs (SkiaSharp.SKSurface surface, SkiaSharp.GRBackendRenderTarget renderTarget, SkiaSharp.GRSurfaceOrigin origin, SkiaSharp.SKColorType colorType, SkiaSharp.GRGlFramebufferInfo glInfo);
```


#### Type Changed: SkiaSharp.Views.UWP.SKSwapChainPanel

Added method:

```csharp
protected override void OnDestroyingContext ();
```



