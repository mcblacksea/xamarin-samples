# API diff: SkiaSharp.Views.Desktop.dll

## SkiaSharp.Views.Desktop.dll

### Removed Namespace SkiaSharp.Views.Desktop


#### Removed Type SkiaSharp.Views.Desktop.Extensions
#### Removed Type SkiaSharp.Views.Desktop.SKControl
#### Removed Type SkiaSharp.Views.Desktop.SKGLControl
#### Removed Type SkiaSharp.Views.Desktop.SKPaintGLSurfaceEventArgs
#### Removed Type SkiaSharp.Views.Desktop.SKPaintSurfaceEventArgs
