# API diff: SkiaSharp.Views.WindowsForms.dll

## SkiaSharp.Views.WindowsForms.dll

> Assembly Version Changed: 2.88.0.0 vs 2.80.0.0

