# API diff: SkiaSharp.Views.Forms.dll

## SkiaSharp.Views.Forms.dll

> Assembly Version Changed: 1.57.0.0 vs 1.56.0.0

### Namespace SkiaSharp.Views.Forms

#### Type Changed: SkiaSharp.Views.Forms.SKCanvasView

Added method:

```csharp
protected override Xamarin.Forms.SizeRequest OnMeasure (double widthConstraint, double heightConstraint);
```


#### Type Changed: SkiaSharp.Views.Forms.SKGLView

Added method:

```csharp
protected override Xamarin.Forms.SizeRequest OnMeasure (double widthConstraint, double heightConstraint);
```



