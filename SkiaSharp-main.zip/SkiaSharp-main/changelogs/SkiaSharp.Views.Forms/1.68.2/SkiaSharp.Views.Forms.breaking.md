# API diff: SkiaSharp.Views.Forms.dll

## SkiaSharp.Views.Forms.dll

### Namespace SkiaSharp.Views.Forms

#### Type Changed: SkiaSharp.Views.Forms.SKImageSourceHandler

Removed method:

```csharp
public virtual System.Threading.Tasks.Task<bool> LoadImageAsync (Xamarin.Forms.Platform.Tizen.Native.Image image, Xamarin.Forms.ImageSource imageSource, System.Threading.CancellationToken cancelationToken);
```



