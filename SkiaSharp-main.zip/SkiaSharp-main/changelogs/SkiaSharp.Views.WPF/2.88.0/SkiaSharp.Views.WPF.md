# API diff: SkiaSharp.Views.WPF.dll

## SkiaSharp.Views.WPF.dll

> Assembly Version Changed: 2.88.0.0 vs 2.80.0.0

