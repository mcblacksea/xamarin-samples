---
name: Question
about: You can ask any question
title: "[QUESTION] "
labels: question
assignees: ''

---

<!--

You can ask questions here, but there might be better places to do that as well:

 - If you have questions on how to use SkiaSharp with .NET, this is the best place.
 - If you have questions on how to draw a picture, but need some suggestions, there is the community to help:
    - StackOverflow: https://stackoverflow.com/questions/tagged/skiasharp
    - Xamarin Forums: https://forums.xamarin.com
    - Gitter.im Chat: https://gitter.im/xamarin/XamarinComponents
 - If you have questions on skia, or need to ask more advanced questions about the native API, the skia Group is the place to go: https://groups.google.com/forum/#!forum/skia-discuss

But... If you still aren't sure about where to ask your question, then go ahead and ask here! We will try and answer you, but if we can't, then we will help you get the answers you want.

-->
