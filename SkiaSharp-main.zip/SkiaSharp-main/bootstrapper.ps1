dotnet tool restore
dotnet cake $args

exit $LASTEXITCODE
