﻿namespace SillyCompany.Mobile.Practices.Presentation.ViewModels.DudeDetails
{
    public class MemeVmo
    {
        public MemeVmo(string memeUrl)
        {
            MemeUrl = memeUrl;
        }

        public string MemeUrl { get; }
    }
}