﻿using Sharpnado.MaterialFrame;

using Xamarin.Forms.Xaml;

namespace SillyCompany.Mobile.Practices.Presentation.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SmallSillySquareCell : MaterialFrame
    {
        public SmallSillySquareCell()
        {
            InitializeComponent();
        }
    }
}