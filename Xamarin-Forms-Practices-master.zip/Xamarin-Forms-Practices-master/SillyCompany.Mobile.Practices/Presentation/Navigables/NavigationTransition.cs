﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NavigationTransition.cs" company="The Silly Company">
//   The Silly Company 2016. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SillyCompany.Mobile.Practices.Presentation.Navigables
{
    /// <summary>
    /// </summary>
    public enum NavigationTransition
    {
        /// <summary>
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// </summary>
        ToResult = 1,
    }
}