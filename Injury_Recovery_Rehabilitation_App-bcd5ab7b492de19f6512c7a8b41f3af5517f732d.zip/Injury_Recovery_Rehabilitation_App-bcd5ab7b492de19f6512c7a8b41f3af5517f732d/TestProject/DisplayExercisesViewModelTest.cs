using NUnit.Framework;

namespace TestProject
{
    public class DisplayExercisesViewModelTest
    {
        [SetUp]
        public void Setup()
        {
            DisplayExercisesViewMode exercisesViewMode = new DisplayExercisesViewMode();
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}