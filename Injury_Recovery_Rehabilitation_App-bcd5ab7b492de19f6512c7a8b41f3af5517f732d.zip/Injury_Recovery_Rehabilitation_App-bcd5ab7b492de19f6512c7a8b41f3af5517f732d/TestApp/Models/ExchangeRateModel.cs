﻿/*
 *Student Name Daniel Dinelli
 * Student Number C00242741
 */
namespace TestApp.Models
{
    /// <summary>
    /// This class maps conversion rates from the exchangeRateApI api to these variables
    /// </summary>
    public class ExchangeRateModel
    {
        public ConversionRate conversion_rates { get; set; }
    }
}
