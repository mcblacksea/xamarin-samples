# SwipeViewDemo
 
Read more about SwipeView on [Microsoft Docs](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/swipeview).
