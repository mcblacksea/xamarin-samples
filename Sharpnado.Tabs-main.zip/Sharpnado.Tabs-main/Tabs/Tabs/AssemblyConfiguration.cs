﻿using Xamarin.Forms;

[assembly: XmlnsDefinition("http://sharpnado.com", "Sharpnado.Tabs")]
[assembly: XmlnsDefinition("http://sharpnado.com", "Sharpnado.Tabs.Effects")]
[assembly: XmlnsPrefix("http://sharpnado.com", "sho")]