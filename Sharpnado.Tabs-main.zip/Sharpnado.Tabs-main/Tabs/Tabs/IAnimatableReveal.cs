﻿namespace Sharpnado.Tabs
{
    public interface IAnimatableReveal
    {
        bool Animate { get; }
    }
}
