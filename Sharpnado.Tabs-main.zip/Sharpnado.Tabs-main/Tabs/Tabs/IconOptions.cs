﻿namespace Sharpnado.Tabs
{
    public enum IconOptions
    {
        LeadingIcon = 0,
        TopIcon = 1,
        IconOnly = 2,
        TextOnly = 3,
    }
}
