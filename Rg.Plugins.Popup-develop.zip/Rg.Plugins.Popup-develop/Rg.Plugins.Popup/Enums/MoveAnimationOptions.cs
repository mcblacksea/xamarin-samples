﻿namespace Rg.Plugins.Popup.Enums
{
    public enum MoveAnimationOptions
    {
        Center,
        Left,
        Right,
        Top,
        Bottom
    }
}
