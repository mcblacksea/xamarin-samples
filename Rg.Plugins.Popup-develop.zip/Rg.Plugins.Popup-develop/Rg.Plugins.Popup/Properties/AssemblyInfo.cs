﻿using Xamarin.Forms;

[assembly: XmlnsDefinition("http://rotorgames.com", "Rg.Plugins.Popup.Animations")]
[assembly: XmlnsDefinition("http://rotorgames.com", "Rg.Plugins.Popup.Pages")]
[assembly: XmlnsPrefix("http://rotorgames.com", "rg")]
