﻿Rg.Plugins.Popup Readme

Project Site: https://github.com/rotorgames/Rg.Plugins.Popup

You can find more information in the documentation: https://github.com/rotorgames/Rg.Plugins.Popup/wiki


****************************** IMPORTANT ****************************************

Please, read GETTING STARTED before to use this plugin: https://github.com/rotorgames/Rg.Plugins.Popup/wiki/Getting-started

There are very important things about initialization and working with the back button on Android.

****************************** IMPORTANT ****************************************