﻿
using Xamarin.Forms;

namespace Demo.Pages
{
    public partial class KeyboardTestPage : ContentPage
    {
        public KeyboardTestPage()
        {
            InitializeComponent();
        }
    }
}
