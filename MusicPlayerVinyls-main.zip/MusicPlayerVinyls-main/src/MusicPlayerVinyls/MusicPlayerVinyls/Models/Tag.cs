﻿namespace MusicPlayerVinyls.Models
{
    public class Tag
    {
        public string Name { get; set; }
    }
}
