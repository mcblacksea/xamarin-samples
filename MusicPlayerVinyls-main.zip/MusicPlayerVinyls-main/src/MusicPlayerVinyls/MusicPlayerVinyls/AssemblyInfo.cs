using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: ExportFont("CrimsonPro-Bold.ttf", Alias = "BoldHeaderFont")]
[assembly: ExportFont("CrimsonPro-Light.ttf", Alias = "LightHeaderFont")]
[assembly: ExportFont("OpenSans-Regular.ttf", Alias = "BodyRegularFont")]
