# XFOpenPDFSample
Sample code to demonstrate how to view PDFs in your Xamarin.Forms app

Video walkthrough of how this works and much more is on my YouTube channel: https://www.youtube.com/watch?v=FqetV1Lh-9c&list=PLfbOp004UaYUgjhTHjtSixo-iMdz6PhIv&index=1
