﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookSwap
{
    public class ScrollMessage
    {
        public const string ScrollChanged = "ScrollChanged";
    }
}
