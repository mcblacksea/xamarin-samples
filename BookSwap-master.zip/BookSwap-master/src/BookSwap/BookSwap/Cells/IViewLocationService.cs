﻿namespace BookSwap.Cells
{
    internal interface IViewLocationService
    {
    }
}