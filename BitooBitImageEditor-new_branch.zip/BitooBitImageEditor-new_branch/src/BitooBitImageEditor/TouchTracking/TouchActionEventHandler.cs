﻿namespace BitooBitImageEditor.TouchTracking
{
    /// <summary>for internal use by <see cref="BitooBitImageEditor"/></summary>
    public delegate void TouchActionEventHandler(object sender, TouchActionEventArgs args);
}
