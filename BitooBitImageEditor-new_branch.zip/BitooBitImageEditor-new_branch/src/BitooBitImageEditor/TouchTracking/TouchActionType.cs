﻿namespace BitooBitImageEditor.TouchTracking
{
#pragma warning disable CS1591 // Отсутствует комментарий XML для открытого видимого типа или члена
    public enum TouchActionType
    {
        Entered,
        Pressed,
        Moved,
        Released,
        Exited,
        Cancelled
    }
#pragma warning restore CS1591 // Отсутствует комментарий XML для открытого видимого типа или члена
}
