﻿namespace BitooBitImageEditor.EditorPage
{
    internal enum ImageEditType
    {
        CropRotate,
        Paint,
        SelectType,
        Text,
        Stickers,
        Info
    }

}
