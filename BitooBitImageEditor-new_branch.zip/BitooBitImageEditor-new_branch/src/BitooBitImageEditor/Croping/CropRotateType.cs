﻿
namespace BitooBitImageEditor.Croping
{
    internal enum CropRotateType
    {
        CropRotate,
        CropFree,
        CropFull,
        CropSquare,
        Crop3_4,
        Crop4_3,
        Crop2_3,
        Crop3_2,
        Crop16_9,
        Crop9_16
    }
}
