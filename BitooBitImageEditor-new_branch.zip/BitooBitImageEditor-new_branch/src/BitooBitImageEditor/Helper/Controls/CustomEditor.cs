﻿
using Xamarin.Forms;

namespace BitooBitImageEditor.Controls
{
    /// <summary>for internal use by <see cref="BitooBitImageEditor"/></summary>
    public class CustomEditor : Editor
    {
    }
}
