﻿
namespace BitooBitImageEditor
{
    /// <summary>for internal use by <see cref="BitooBitImageEditor"/></summary>
    public interface IPlatformHelper
    {
        /// <summary>for internal use by <see cref="BitooBitImageEditor"/></summary>
        bool IsInitialized { get; }
    }
}
