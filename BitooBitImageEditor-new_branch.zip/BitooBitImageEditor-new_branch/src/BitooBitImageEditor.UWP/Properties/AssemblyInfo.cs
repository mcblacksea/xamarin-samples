﻿using System.Reflection;
using System.Runtime.InteropServices;

// Общие сведения об этой сборке предоставляются следующим набором 
// набора атрибутов. Измените значения этих атрибутов, чтобы изменить сведения,
// связанные со сборкой.
[assembly: AssemblyTitle("BitooBitImageEditor.UWP")]
[assembly: AssemblyDescription("simple image editor for xamarin")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BitooBit")]
[assembly: AssemblyProduct("BitooBitImageEditor.UWP")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyTrademark("BitooBit")]
[assembly: AssemblyCulture("")]

// Сведения о версии для сборки состоят из следующих четырех значений:
//
//      Основной номер версии
//      Дополнительный номер версии 
//      Номер сборки
//      Номер редакции
//
// Можно задать все значения или принять номера сборки и редакции по умолчанию 
// используя "*", как показано ниже:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.1.7")]
[assembly: AssemblyFileVersion("1.0.1.7")]
[assembly: ComVisible(false)]