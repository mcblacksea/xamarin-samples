﻿using Xamarin.Forms;

[assembly: XmlnsDefinition("http://sharpnado.com", "Sharpnado.MaterialFrame")]
[assembly: XmlnsPrefix("http://sharpnado.com", "sho")]