# CalendarsTester
Basic interactive app for manually testing the [Calendars plugin](https://github.com/TheAlmightyBob/Calendars)

Runs on iOS/Android/Windows.

Note that some operations are only available as context actions (swipe left on iOS, long-press on Android/Windows).

[![Build status](https://build.appcenter.ms/v0.1/apps/dfb6e157-4a12-4fcc-a5d0-f7544fa66e4c/branches/master/badge)](https://appcenter.ms)
