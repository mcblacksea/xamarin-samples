﻿namespace CalendarsTester.Core.Enums
{
    public enum ModalResult
    {
        Canceled,
        Done,
        Deleted
    }
}
