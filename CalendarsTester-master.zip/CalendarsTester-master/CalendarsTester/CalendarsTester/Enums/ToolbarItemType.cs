﻿namespace CalendarsTester.Enums
{
    public enum ToolbarItemType
    {
        Standard,
        Cancel,
        Done,
        Add,
        Refresh,
        Search
    }
}