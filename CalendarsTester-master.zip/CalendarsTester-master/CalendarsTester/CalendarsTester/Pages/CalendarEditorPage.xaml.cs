﻿using Xamarin.Forms;

namespace CalendarsTester.Pages
{
    public partial class CalendarEditorPage : ContentPage
    {
        public CalendarEditorPage()
        {
            InitializeComponent();
        }
    }
}
