﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CalendarsTester.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RemindersPage : ContentPage
    {
        public RemindersPage()
        {
            InitializeComponent();

        }
    }
}
