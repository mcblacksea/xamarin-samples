﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SampleApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class WeekViewPage : ContentPage
    {
        public WeekViewPage()
        {
            InitializeComponent();
        }
    }
}
