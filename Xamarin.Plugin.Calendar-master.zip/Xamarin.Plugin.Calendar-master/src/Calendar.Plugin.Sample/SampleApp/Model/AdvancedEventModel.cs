﻿using System;

namespace SampleApp.Model
{
    public class AdvancedEventModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime Starting { get; set; }
    }
}
