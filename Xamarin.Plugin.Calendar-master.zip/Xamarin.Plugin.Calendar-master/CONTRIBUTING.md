### How to contribute
- If you find an issue with the plugin, please feel free to open up a Bug report issue
- If you have any ideas for improvement, please feel free to open up a Feature Request issue
- You can join our telegram [group chat](https://t.me/XamarinPluginCalendar)
- Any questions or anything you can ask in the group or open up an issue

We are open to all suggestions and feedback :)

If you want to help us with developing of plugin you can do that too :)
Few simple rules apply:
- Be consistent with the current implementation of the plugin
- Clean code, formatting bla bla :)
