﻿using System.Windows;
using LibVLCSharp.Shared;

namespace LibVLCSharp.WPF.Sample
{
    public partial class App : Application
    {
        public App()
        {
        }
    }
}