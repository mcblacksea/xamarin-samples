﻿using System.Windows;

namespace LibVLCSharp.Forms.WPF.Sample
{
    public partial class App : Application
    {
    }
}