﻿using AppKit;

namespace LibVLCSharp.Mac.Sample
{
    static class MainClass
    {
        static void Main(string[] args)
        {
            NSApplication.Init();
            NSApplication.Main(args);
        }
    }
}
