﻿using ReactiveUI;

namespace LibVLCSharp.Avalonia.Sample.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
