# LibVLCSharp.Avalonia.Sample

## Windows

The Windows project includes the appropriate NuGet package for the native Windows VLC runtime.

## MacOS

The MacOS project includes the approprate NuGet package for the native MacOS VLC runtime.

## Linux

The Linux project does not include any additional native NuGet packages.

To run on linux, please refer to the [Linux guide](../../docs/linux-setup.md).
