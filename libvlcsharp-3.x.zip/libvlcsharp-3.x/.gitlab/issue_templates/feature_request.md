<!---
Please read this!

Before opening a new issue, make sure to search for keywords in the issues
filtered by "feature" label and verify the issue you're about to submit isn't a duplicate.

If you are using LibVLCSharp commercially, please consider purchasing a Commercial License: https://videolabs.io/solutions/libvlcsharp

If this is a question please ask on StackOverflow: https://stackoverflow.com/questions/tagged/libvlcsharp.

Need professional support? Reach out at dotnet@videolabs.io for more info.
--->

### Problem to solve

<!-- What problem do we solve? -->

### Intended users

<!-- Who will use this feature? -->

### Proposal

<!-- How are we going to solve the problem? -->
<!-- Include use cases, benefits, and/or goals -->

### Documentation

<!-- What kind of documentation is needed for this feature? -->