﻿namespace LibVLCSharp.Forms.Shared
{
    internal interface ISystemUI
    {
        void ShowSystemUI();
        void HideSystemUI();
    }
}
