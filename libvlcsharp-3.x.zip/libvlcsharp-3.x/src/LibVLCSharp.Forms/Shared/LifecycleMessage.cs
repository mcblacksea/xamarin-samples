﻿namespace LibVLCSharp.Forms.Shared
{
    /// <summary>
    /// Lifecycle message
    /// </summary>
    public class LifecycleMessage
    {
    }
}
