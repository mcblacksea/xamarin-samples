﻿#if IOS
namespace LibVLCSharp.Forms.Platforms.iOS
{
    /// <summary>
    /// Empty shell used to load the custom renderer assembly.
    /// </summary>
    internal static class Platform
    {
        /// <summary>
        /// Call this to load the custom renderer assembly.
        /// </summary>
        internal static void Init()
        {
        }
    }
}
#endif
