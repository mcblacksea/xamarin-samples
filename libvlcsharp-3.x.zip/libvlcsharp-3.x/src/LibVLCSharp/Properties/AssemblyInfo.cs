﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LibVLCSharp.Forms")]
[assembly: InternalsVisibleTo("LibVLCSharp.Uno")]
