﻿namespace LibVLCSharp.Forms.Platforms.WPF
{
    /// <summary>
    /// Empty shell used to load the custom renderer assembly.
    /// </summary>
    public static class Platform
    {
        /// <summary>
        /// Call this to load the custom renderer assembly.
        /// </summary>
        public static void Init()
        {
        }
    }
}
