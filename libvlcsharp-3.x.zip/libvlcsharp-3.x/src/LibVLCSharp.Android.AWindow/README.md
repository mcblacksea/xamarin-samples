# LibVLCSharp.Android.AWindow

This project is an implementation detail for LibVLCSharp on the android platform.

libvlc for android needs the AWindow class, which is provided by the Jars/org.videolan.libvlc.aar file.
This project generates Xamarin bindings for this java classes.