#!/bin/bash
dotnet run --project LibVLCSharp.Tests/LibVLCSharp.Tests.csproj