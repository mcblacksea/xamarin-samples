﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.Styles
{
    public partial class DefaultTheme : ResourceDictionary
    {
        public DefaultTheme()
        {
            InitializeComponent();
        }
    }
}