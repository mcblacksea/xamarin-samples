﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.ViewModels.Base
{
    public class ViewModelBase : BindableObject
    {

    }
}