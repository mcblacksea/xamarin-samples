﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.Views
{
    public partial class RestaurantDetailView : ContentView
    {
        public RestaurantDetailView()
        {
            InitializeComponent();
        }
    }
}