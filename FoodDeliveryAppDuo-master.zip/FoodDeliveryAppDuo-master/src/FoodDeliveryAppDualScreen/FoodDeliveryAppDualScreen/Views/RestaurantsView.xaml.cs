﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.Views
{
    public partial class RestaurantsView : ContentView
    {
        public RestaurantsView()
        {
            InitializeComponent();
        }
    }
}