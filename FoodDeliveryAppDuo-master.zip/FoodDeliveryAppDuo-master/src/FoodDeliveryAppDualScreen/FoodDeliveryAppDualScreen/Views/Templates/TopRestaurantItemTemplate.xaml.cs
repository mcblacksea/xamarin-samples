﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.Views.Templates
{
    public partial class TopRestaurantItemTemplate : ContentView
    {
        public TopRestaurantItemTemplate()
        {
            InitializeComponent();
        }
    }
}