﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.Views.Templates
{
    public partial class RestaurantItemTemplate : ContentView
    {
        public RestaurantItemTemplate()
        {
            InitializeComponent();
        }
    }
}