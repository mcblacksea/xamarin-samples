﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.Views.Templates
{
    public partial class FoodItemTemplate : ContentView
    {
        public FoodItemTemplate()
        {
            InitializeComponent();
        }
    }
}