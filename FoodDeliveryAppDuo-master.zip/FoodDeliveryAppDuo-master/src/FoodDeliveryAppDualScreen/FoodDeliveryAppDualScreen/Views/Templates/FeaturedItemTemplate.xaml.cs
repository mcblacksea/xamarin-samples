﻿using Xamarin.Forms;

namespace FoodDeliveryAppDualScreen.Views.Templates
{
    public partial class FeaturedItemTemplate : ContentView
    {
        public FeaturedItemTemplate()
        {
            InitializeComponent();
        }
    }
}
