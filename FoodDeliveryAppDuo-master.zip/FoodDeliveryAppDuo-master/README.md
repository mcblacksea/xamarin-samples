# FoodDeliveryAppDuo

Xamarin.Forms good looking UI sample for Surface Duo.

<img src="images/FoodDeliveryDuoApp.gif" Width="600" />

### Platforms

Android.

## Copyright and license

Code released under the [MIT license](https://opensource.org/licenses/MIT).