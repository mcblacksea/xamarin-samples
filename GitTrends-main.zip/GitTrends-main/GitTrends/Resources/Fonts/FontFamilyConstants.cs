﻿namespace GitTrends
{
	static class FontFamilyConstants
	{
		public const string RobotoBold = "Roboto-Bold";
		public const string RobotoMedium = "Roboto-Medium";
		public const string RobotoRegular = "Roboto-Regular";
		public const string FontAwesomeBrands = "Font Awesome 5 Brands";
		public const string FontAwesome = "Font Awesome 5 Free";
	}
}