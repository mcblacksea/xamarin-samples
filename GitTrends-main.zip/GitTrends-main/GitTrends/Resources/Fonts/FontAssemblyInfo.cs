﻿using GitTrends;
using Xamarin.Forms;

[assembly: ExportFont("Roboto-Bold.ttf", Alias = FontFamilyConstants.RobotoBold)]
[assembly: ExportFont("Roboto-Medium.ttf", Alias = FontFamilyConstants.RobotoMedium)]
[assembly: ExportFont("Roboto-Regular.ttf", Alias = FontFamilyConstants.RobotoRegular)]
[assembly: ExportFont("FontAwesome.otf", Alias = FontFamilyConstants.FontAwesome)]
[assembly: ExportFont("FontAwesomeBrands.ttf", Alias = FontFamilyConstants.FontAwesomeBrands)]