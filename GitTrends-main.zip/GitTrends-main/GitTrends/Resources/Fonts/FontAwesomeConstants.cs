﻿namespace GitTrends
{
	static class FontAwesomeConstants
	{
		public const char Information = '\uf129';
		public const char ExternalLink = '\uf35d';
	}
}