wget https://dot.net/v1/dotnet-install.sh
chmod +x dotnet-install.sh
./dotnet-install.sh --version $netversion --install-dir "$AGENT_TOOLSDIRECTORY/dotnet"