﻿namespace GitTrends.Mobile.Common
{
	public enum PreferredTheme { Default, Light, Dark }
}