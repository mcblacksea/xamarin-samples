﻿namespace GitTrends.Mobile.Common
{
	public enum FloatingActionButtonType { Information, Statistic1, Statistic2, Statistic3 }
}