﻿namespace GitTrends.Mobile.Common
{
	public enum RefreshState { Uninitialized, Succeeded, LoginExpired, MaximumApiLimit, AbuseLimit, Error }
}