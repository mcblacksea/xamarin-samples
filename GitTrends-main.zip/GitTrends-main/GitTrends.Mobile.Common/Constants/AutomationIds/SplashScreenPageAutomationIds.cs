﻿namespace GitTrends.Mobile.Common
{
	public static class SplashScreenPageAutomationIds
	{
		public const string StatusLabel = nameof(SplashScreenPageAutomationIds) + nameof(StatusLabel);
		public const string GitTrendsImage = nameof(SplashScreenPageAutomationIds) + nameof(GitTrendsImage);
	}
}