﻿namespace GitTrends.Mobile.Common
{
	public static class FontAwesomeBrandsConstants
	{
		public const string GitHubOctocat = "\uf09b";
	}
}