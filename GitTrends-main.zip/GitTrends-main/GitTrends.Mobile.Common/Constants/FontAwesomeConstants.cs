﻿namespace GitTrends.Mobile.Common
{
	static class FontAwesomeConstants
	{
		public const string Bell = "\uf0f3";
	}
}