﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("GitTrends.UnitTests")]