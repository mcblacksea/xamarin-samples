﻿using System;
namespace GitTrends.Shared
{
	public record NuGetPackageModel(string PackageName, Uri IconUri, Uri WebsiteUri);
}