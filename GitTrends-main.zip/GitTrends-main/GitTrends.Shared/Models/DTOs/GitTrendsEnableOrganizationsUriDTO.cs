﻿using System;
namespace GitTrends.Shared
{
	public record GitTrendsEnableOrganizationsUriDTO(Uri Uri);
}