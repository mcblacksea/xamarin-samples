﻿namespace GitTrends.Shared
{
	public record GitHubUserResponse(User User);

	public record GitHubOrganizationResponse(User Organization);
}