﻿namespace GitTrends.Shared
{
	public record GetGitHubClientIdDTO(string ClientId);
}