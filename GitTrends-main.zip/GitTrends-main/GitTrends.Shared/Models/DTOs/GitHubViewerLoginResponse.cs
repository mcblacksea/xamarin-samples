﻿namespace GitTrends.Shared
{
	public record GitHubViewerLoginResponse(User Viewer);
}