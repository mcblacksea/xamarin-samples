﻿namespace GitTrends.Shared
{
#pragma warning disable IDE1006 // Naming Styles
	public record AppCenterApiKeyDTO(string iOS, string Android);
#pragma warning restore IDE1006 // Naming Styles
}