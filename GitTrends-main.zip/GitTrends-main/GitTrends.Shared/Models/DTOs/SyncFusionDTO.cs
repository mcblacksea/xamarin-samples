﻿namespace GitTrends.Shared
{
	public record SyncFusionDTO(string LicenseKey, long LicenseVersion);
}