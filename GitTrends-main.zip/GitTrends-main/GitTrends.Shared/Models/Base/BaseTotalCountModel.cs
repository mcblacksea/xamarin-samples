﻿namespace GitTrends.Shared
{
	public abstract record BaseTotalCountModel(long TotalCount, long TotalUniqueCount);
}