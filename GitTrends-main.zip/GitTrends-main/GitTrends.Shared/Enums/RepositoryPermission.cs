﻿namespace GitTrends.Shared
{
	public enum RepositoryPermission { UNKNOWN, ADMIN, MAINTAIN, WRITE, TRIAGE, READ }
}