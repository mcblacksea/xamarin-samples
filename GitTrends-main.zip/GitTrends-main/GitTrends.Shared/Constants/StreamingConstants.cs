﻿namespace GitTrends.Shared
{
	public static class StreamingConstants
	{
		public const string Chart = nameof(Chart);
		public const string EnableOrganizations = nameof(EnableOrganizations);
	}
}