﻿namespace GitTrends.iOS
{
    public class Application
    {
        static void Main(string[] args) => UIKit.UIApplication.Main(args, null, typeof(AppDelegate));
    }
}
