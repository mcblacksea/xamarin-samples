# Bethanys Pie Shop Mobile (Xamarin.Forms)
Xamarin reference architecture, used in Pluralsight course "Building an Enterprise Mobile Application with Xamarin.Forms"
