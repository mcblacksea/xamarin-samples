﻿namespace BethanysPieShop.Mobile.Core.Constants
{
    public class CacheNameConstants
    {
        public const string AllPies = "AllPies";
        public const string PiesOfTheWeek = "PiesOfTheWeek";
        public const string ShoppingCart = "ShoppingCart";
    }
}
