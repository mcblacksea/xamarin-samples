﻿namespace BethanysPieShop.Mobile.Core.Constants
{
    public class MessagingConstants
    {
        public const string AddPieToBasket = "AddPieToBasket";
    }
}
