﻿namespace BethanysPieShop.Mobile.Core.Contracts.Services.General
{
    public  interface IPhoneService
    {
        void MakePhoneCall();
    }
}
