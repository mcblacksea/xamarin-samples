﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BethanysPieShop.Mobile.Core.Templates
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class PieTemplate : ContentView
	{
		public PieTemplate ()
		{
			InitializeComponent ();
		}
	}
}