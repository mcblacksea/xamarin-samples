﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("QuickJournal.iOS")]
[assembly: AssemblyDescription("A trivial sample that demonstrates how to use the Realm database.")]
[assembly: AssemblyCompany("Realm")]
[assembly: AssemblyProduct("QuickJournal.iOS")]
[assembly: AssemblyCopyright("Copyright © Realm 2020")]
[assembly: ComVisible(false)]
[assembly: Guid("72bdc44f-c588-44f3-b6df-9aace7daafdd")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
