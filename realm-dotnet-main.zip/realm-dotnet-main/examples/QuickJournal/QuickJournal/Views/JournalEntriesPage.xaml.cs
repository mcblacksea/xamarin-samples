﻿namespace QuickJournal.Views
{
    public partial class JournalEntriesPage : BasePage
    {
        public JournalEntriesPage()
        {
            InitializeComponent();
        }
    }
}

