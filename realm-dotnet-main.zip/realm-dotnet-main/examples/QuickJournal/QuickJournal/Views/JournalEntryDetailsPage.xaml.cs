﻿namespace QuickJournal.Views
{
    public partial class JournalEntryDetailsPage : BasePage
    {
        public JournalEntryDetailsPage()
        {
            InitializeComponent();
        }
    }
}

