This package contains third-party software components governed by the license(s) indicated below:

In the event that we accidentally failed to list a required notice,
please bring it to our attention by emailing us at:
realm-help@mongodb.com


| Component                              | License Type | License URL                                                                       |
|----------------------------------------|--------------|-----------------------------------------------------------------------------------|
| MongoDB.Bson                           | Apache-2.0   | [License](https://github.com/mongodb/mongo-csharp-driver/blob/master/License.txt) |
| Remotion.Linq                          | Apache-2.0   | [License](https://relinq.codeplex.com/)                                           |
| System.Buffers                         | MIT          | [License](https://github.com/dotnet/corefx/blob/master/LICENSE.TXT)               |
| System.Runtime.CompilerServices.Unsafe | MIT          | [License](https://github.com/dotnet/runtime/blob/main/LICENSE.TXT)                |