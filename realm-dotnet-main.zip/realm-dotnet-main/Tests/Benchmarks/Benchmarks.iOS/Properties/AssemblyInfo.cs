﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Benchmarks.iOS")]
[assembly: AssemblyDescription("Entry point for the Xamarin.Forms app used to run Benchmarks for Realm")]
[assembly: AssemblyCompany("Realm Inc.")]
[assembly: AssemblyProduct("Benchmarks.iOS")]
[assembly: AssemblyCopyright("Copyright © 2021")]
[assembly: ComVisible(false)]

[assembly: Guid("72bdc44f-c588-44f3-b6df-9aace7daafdd")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
