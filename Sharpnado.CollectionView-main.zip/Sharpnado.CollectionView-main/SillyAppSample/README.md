## The main HorizontalListView sample is the Silly! App.

If you want play with the `HorizontalListView`, go to https://github.com/roubachof/Xamarin-Forms-Practices.

## Setup

1. Clone the Xamarin-Forms-Practices repo
2. Initialize its submodules

```
git clone https://github.com/roubachof/Xamarin-Forms-Practices.git
git submodule update --init
```