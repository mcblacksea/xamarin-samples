﻿using Xamarin.Forms;
using Xamarin.Forms.Internals;

[assembly: Preserve]

[assembly: XmlnsDefinition("http://sharpnado.com", "Sharpnado.CollectionView.RenderedViews")]
[assembly: XmlnsDefinition("http://sharpnado.com", "Sharpnado.CollectionView.Effects")]
[assembly: XmlnsPrefix("http://sharpnado.com", "sho")]