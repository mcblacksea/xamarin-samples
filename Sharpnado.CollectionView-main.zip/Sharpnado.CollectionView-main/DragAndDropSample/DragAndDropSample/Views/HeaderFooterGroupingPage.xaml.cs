﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DragAndDropSample.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HeaderFooterGroupingPage : ContentPage
    {
        public HeaderFooterGroupingPage()
        {
            InitializeComponent();
        }
    }
}