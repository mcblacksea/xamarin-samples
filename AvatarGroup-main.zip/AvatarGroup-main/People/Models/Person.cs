﻿using System;
using System.Collections.Generic;
using System.Text;

namespace People.Models
{
    public class Person
    {
        public string Image { get; set; }
    }
}
