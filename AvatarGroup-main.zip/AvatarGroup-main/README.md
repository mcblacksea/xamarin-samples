# AvatarGroup
Simple example of an Avatar Group in Xamarin Forms
