rm -rf Pods/*
arch -x86_64 pod install

