//
//  nativeLibsPlaceholder.h
//  nativeLibsPlaceholder
//
//  Created by Marius Ungureanu on 11/16/20.
//

#import <Foundation/Foundation.h>

//! Project version number for nativeLibsPlaceholder.
FOUNDATION_EXPORT double nativeLibsPlaceholderVersionNumber;

//! Project version string for nativeLibsPlaceholder.
FOUNDATION_EXPORT const unsigned char nativeLibsPlaceholderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <nativeLibsPlaceholder/PublicHeader.h>


