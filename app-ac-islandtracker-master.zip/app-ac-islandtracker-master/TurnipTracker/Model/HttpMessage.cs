﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurnipTracker.Model
{
    public class HttpMessage
    {
        public string Message { get; set; }
    }
}
