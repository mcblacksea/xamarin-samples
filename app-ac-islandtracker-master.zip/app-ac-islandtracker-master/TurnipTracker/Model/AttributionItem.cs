﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurnipTracker.Model
{
    public class AttributionItem
    {
        public string Text { get; set; }
        public string Tag { get; set; }
    }
}
