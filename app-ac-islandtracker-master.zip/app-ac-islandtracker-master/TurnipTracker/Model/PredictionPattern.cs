﻿using System;
namespace TurnipTracker.Model
{
    public enum PredictionPattern
    {
        IDontKnow,
        Fluctuating,
        SmallSpike,
        LargeSpike,
        Decreasing,
        All,
    }
}