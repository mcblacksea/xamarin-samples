﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurnipTracker.Model
{
    public enum GateStatus
    {
        Closed = 0,
        Everyone = 1,
        BestFriends = 2,
        DodoCode = 3
    }
}
