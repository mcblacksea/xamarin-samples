﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurnipTracker.Shared
{
    public class Friend
    {
        public string MyPublicKey { get; set; }
        public string FriendPublicKey { get; set; }
    }
}
