﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurnipTracker.Shared
{
    public class ProStatus
    {
        public string PublicKey { get; set; }
        public bool IsPro { get; set; }

        public string Receipt { get;set; }
    }
}
