﻿using System;

using Xamarin.Forms;

namespace AppEssentials.Shared.Models
{
    public class MasterPageItem
    {
        public string Title { get; set; }

        public string IconSource { get; set; }

        public Type TargetType { get; set; }
    }
}

