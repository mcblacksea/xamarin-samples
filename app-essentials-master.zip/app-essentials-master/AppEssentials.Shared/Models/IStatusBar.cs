﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppEssentials.Shared.Models
{
    public interface IStatusBar
    {
        void SetStatusBarColor(System.Drawing.Color color);
    }
}
