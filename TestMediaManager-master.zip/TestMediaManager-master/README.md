# TestMediaManager
Test app for martijn00/XamarinMediaManager

* VS2019
* Xamarin.Forms 3.6.0.293080
* Plugin.MediaManager.Forms 0.5.0

https://github.com/martijn00/XamarinMediaManager/issues/435
